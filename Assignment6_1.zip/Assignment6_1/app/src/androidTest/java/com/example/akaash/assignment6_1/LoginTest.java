package com.example.akaash.assignment6_1;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by AKAASH on 04-11-2017.
 */
public class LoginTest {
    @Test
    public void login()
    {

        //assertThat();
    }

}